Biblioteka do analizowania Warszawskich autobusów, a dokładnie ich prędkości i opóźnień.
